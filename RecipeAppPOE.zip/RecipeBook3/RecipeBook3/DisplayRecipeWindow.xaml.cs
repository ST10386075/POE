﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBook3
{
    /// <summary>
    /// Interaction logic for DisplayRecipeWindow.xaml
    /// </summary>
    public partial class DisplayRecipeWindow : Window
    {
        private List<Recipe> recipes;
        private List<Ingredient> ingredients;

        public DisplayRecipeWindow()
        {
            InitializeComponent();
            LoadRecipes();
        }

        private void LoadRecipes()
        {
            recipes = new List<Recipe>();

            string recipesDirectory = "Recipes";
            if (Directory.Exists(recipesDirectory))
            {
                foreach (var file in Directory.GetFiles(recipesDirectory, "*.json"))
                {
                    string json = File.ReadAllText(file);
                    var recipe = JsonSerializer.Deserialize<Recipe>(json);
                    recipes.Add(recipe);
                }
            }

            RecipeListBox.ItemsSource = recipes.OrderBy(r => r.Name).Select(r => r.Name).ToList();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchQuery = SearchRecipeTextBox.Text.ToLower();
            var filteredRecipes = recipes
                .Where(r => r.Name.ToLower().Contains(searchQuery))
                .OrderBy(r => r.Name)
                .Select(r => r.Name)
                .ToList();

            RecipeListBox.ItemsSource = filteredRecipes;
        }

        private void RecipeListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (RecipeListBox.SelectedItem != null)
            {
                string selectedRecipeName = RecipeListBox.SelectedItem.ToString();
                var selectedRecipe = recipes.FirstOrDefault(r => r.Name == selectedRecipeName);
                DisplayRecipe(selectedRecipe);
            }
        }

        private void DisplayRecipe(Recipe recipe)
        {
            if (recipe != null)
            {
                RecipeDetailsTextBlock.Text = $"Name: {recipe.Name}\n\nIngredients:\n";

                foreach (var ingredient in recipe.Ingredients)
                {
                    RecipeDetailsTextBlock.Text += $"{ingredient.Amount} {ingredient.Unit} {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})\n";
                }

                RecipeDetailsTextBlock.Text += $"\nSteps:\n{recipe.Steps}";
            }
        }

        public class Ingredient
        {
            public string Name { get; set; }
            public double Amount { get; set; }
            public string Unit { get; set; }
            public double Calories { get; set; }
            public string FoodGroup { get; set; }
        }

        public class Recipe
        {
            public string Name { get; set; }
            public string Steps { get; set; }
            public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        }
    }
}
