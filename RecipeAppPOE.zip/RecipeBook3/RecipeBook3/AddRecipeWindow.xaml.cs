﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBook3
{
    /// <summary>
    /// Interaction logic for AddRecipeWindow.xaml
    /// </summary>
    public partial class AddRecipeWindow : Window
    {
        private List<Ingredient> ingredients;
        public AddRecipeWindow()
        {
            InitializeComponent();
            ingredients = new List<Ingredient>();
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            StackPanel ingredientPanel = new StackPanel { Orientation = Orientation.Horizontal };
            TextBox ingredientName = new TextBox { Width = 120, Margin = new Thickness(0, 5, 10, 5) };
            TextBox ingredientAmount = new TextBox { Width = 50, Margin = new Thickness(0, 5, 10, 5) };
            TextBox ingredientUnit = new TextBox { Width = 50, Margin = new Thickness(0, 5, 10, 5) };
            TextBox ingredientCalories = new TextBox { Width = 50, Margin = new Thickness(0, 5, 10, 5) };
            TextBox ingredientFoodGroup = new TextBox { Width = 70, Margin = new Thickness(0, 5, 10, 5) };

            ingredientPanel.Children.Add(ingredientName);
            ingredientPanel.Children.Add(ingredientAmount);
            ingredientPanel.Children.Add(ingredientUnit);
            ingredientPanel.Children.Add(ingredientCalories);
            ingredientPanel.Children.Add(ingredientFoodGroup);

            IngredientsPanel.Children.Add(ingredientPanel);
        }

        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            string steps = StepsTextBox.Text;

            ingredients.Clear();
            foreach (StackPanel panel in IngredientsPanel.Children)
            {
                var ingredientName = ((TextBox)panel.Children[0]).Text;
                var ingredientAmount = ((TextBox)panel.Children[1]).Text;
                var ingredientUnit = ((TextBox)panel.Children[2]).Text;
                var ingredientCalories = ((TextBox)panel.Children[3]).Text;
                var ingredientFoodGroup = ((TextBox)panel.Children[4]).Text;

                if (!string.IsNullOrWhiteSpace(ingredientName) &&
                    double.TryParse(ingredientAmount, out double amount) &&
                    double.TryParse(ingredientCalories, out double calories))
                {
                    ingredients.Add(new Ingredient
                    {
                        Name = ingredientName,
                        Amount = amount,
                        Unit = ingredientUnit,
                        Calories = calories,
                        FoodGroup = ingredientFoodGroup
                    });
                }
            }

            double totalCalories = ingredients.Sum(i => i.Calories * i.Amount);
            if (totalCalories > 300)
            {
                MessageBox.Show("Warning: Total calories exceed 300!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            SaveRecipe(recipeName, steps, ingredients);

            MessageBox.Show("Recipe saved successfully!");

            ResetForm();
        }

        private void SaveRecipe(string recipeName, string steps, List<Ingredient> ingredients)
        {
            var recipe = new Recipe
            {
                Name = recipeName,
                Steps = steps,
                Ingredients = ingredients
            };

            string json = JsonSerializer.Serialize(recipe);
            string path = System.IO.Path.Combine("Recipes", $"{recipeName}.json");
            Directory.CreateDirectory("Recipes");
            File.WriteAllText(path, json);
        }

        private void ResetForm()
        {
            RecipeNameTextBox.Clear();
            StepsTextBox.Clear();
            IngredientsPanel.Children.Clear();
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Amount { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public string Steps { get; set; }
        public List<Ingredient> Ingredients { get; set; }
    }
}
