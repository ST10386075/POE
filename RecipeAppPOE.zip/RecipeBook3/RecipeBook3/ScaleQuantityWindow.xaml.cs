﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBook3
{
    /// <summary>
    /// Interaction logic for ScaleQuantityWindow.xaml
    /// </summary>
    public partial class ScaleQuantityWindow : Window
    {
        private ObservableCollection<Ingredient> _ingredients;
        private List<Recipe> _recipes;

        public ScaleQuantityWindow()
        {
            InitializeComponent();
            LoadRecipes();
            RecipeComboBox.ItemsSource = _recipes.Select(r => r.Name).ToList();
        }

        private void LoadRecipes()
        {
            _recipes = new List<Recipe>();
            var recipeFiles = Directory.GetFiles("Recipes", "*.json");
            foreach (var file in recipeFiles)
            {
                var json = File.ReadAllText(file);
                var recipe = JsonSerializer.Deserialize<Recipe>(json);
                _recipes.Add(recipe);
            }
        }

        private void RecipeComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem is string selectedRecipeName)
            {
                var selectedRecipe = _recipes.FirstOrDefault(r => r.Name == selectedRecipeName);
                if (selectedRecipe != null)
                {
                    _ingredients = new ObservableCollection<Ingredient>(selectedRecipe.Ingredients);
                    IngredientsListView.ItemsSource = _ingredients;
                }
            }
        }

        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button button && double.TryParse(button.Tag.ToString(), out double scale))
            {
                foreach (var ingredient in _ingredients)
                {
                    ingredient.Amount *= scale;
                }
                IngredientsListView.Items.Refresh();
            }
        }

        private void ResetScaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem is string selectedRecipeName)
            {
                var selectedRecipe = _recipes.FirstOrDefault(r => r.Name == selectedRecipeName);
                if (selectedRecipe != null)
                {
                    _ingredients = new ObservableCollection<Ingredient>(selectedRecipe.Ingredients);
                    IngredientsListView.ItemsSource = _ingredients;
                }
            }
        }
    }
}
