﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBook3
{
    /// <summary>
    /// Interaction logic for RemoveRecipeWindow.xaml
    /// </summary>
    public partial class RemoveRecipeWindow : Window
    {
        private List<Recipe> _recipes;

        public RemoveRecipeWindow()
        {
            InitializeComponent();
            LoadRecipes();
            RecipeComboBox.ItemsSource = _recipes.Select(r => r.Name).ToList();
        }

        private void LoadRecipes()
        {
            _recipes = new List<Recipe>();
            var recipeFiles = Directory.GetFiles("Recipes", "*.json");
            foreach (var file in recipeFiles)
            {
                var json = File.ReadAllText(file);
                var recipe = JsonSerializer.Deserialize<Recipe>(json);
                _recipes.Add(recipe);
            }
        }

        private void RemoveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem is string selectedRecipeName)
            {
                var recipeFile = System.IO.Path.Combine("Recipes", $"{selectedRecipeName}.json");
                if (File.Exists(recipeFile))
                {
                    File.Delete(recipeFile);
                    MessageBox.Show($"Recipe '{selectedRecipeName}' removed successfully!");

                    // Refresh the recipe list
                    LoadRecipes();
                    RecipeComboBox.ItemsSource = _recipes.Select(r => r.Name).ToList();
                }
                else
                {
                    MessageBox.Show("Recipe file not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe to remove.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void RemoveAllRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            var recipeFiles = Directory.GetFiles("Recipes", "*.json");
            foreach (var file in recipeFiles)
            {
                File.Delete(file);
            }

            MessageBox.Show("All recipes removed successfully!");

            // Refresh the recipe list
            LoadRecipes();
            RecipeComboBox.ItemsSource = _recipes.Select(r => r.Name).ToList();
        }
    }

}
