﻿using OxyPlot;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBook3
{
    /// <summary>
    /// Interaction logic for PieChartWindow.xaml
    /// </summary>
    public partial class PieChartWindow : Window
    {
        private List<Recipe> _recipes;

        public PlotModel PieChartPlotView { get; private set; }

        public PieChartWindow()
        {
            InitializeComponent();
            LoadRecipes();
            CreatePieChart();
        }

        private void LoadRecipes()
        {
            _recipes = new List<Recipe>();
            var recipeFiles = Directory.GetFiles("Recipes", "*.json");
            foreach (var file in recipeFiles)
            {
                var json = File.ReadAllText(file);
                var recipe = JsonSerializer.Deserialize<Recipe>(json);
                _recipes.Add(recipe);
            }
        }

        private void CreatePieChart()
        {
            var pieSeries = new OxyPlot.Series.PieSeries { StrokeThickness = 2.0, InsideLabelPosition = 0.5, AngleSpan = 360, StartAngle = 0 };

            foreach (var recipe in _recipes)
            {
                double totalCalories = recipe.Ingredients.Sum(i => i.Calories * i.Amount);
                pieSeries.Slices.Add(new PieSlice(recipe.Name, totalCalories));
            }

            var plotModel = new PlotModel { Title = "Calories in Each Recipe" };
            plotModel.Series.Add(pieSeries);

            PieChartPlotView = plotModel;
        }
    }


}
