﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBook3
{
    /// <summary>
    /// Interaction logic for MenuWindow.xaml
    /// </summary>
    public partial class MenuWindow : Window
    {
        public MenuWindow()
        {
            InitializeComponent();
        }

        private void btnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow();
            addRecipeWindow.ShowDialog();
        }

        private void btnDisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeWindow displayRecipeWindow = new DisplayRecipeWindow();
            displayRecipeWindow.ShowDialog();
        }

        private void btnScaleQuantity_Click(object sender, RoutedEventArgs e)
        {
            ScaleQuantityWindow scaleQuantityWindow = new ScaleQuantityWindow();
            scaleQuantityWindow.ShowDialog();
        }

        private void btnSearchPieChart_Click(object sender, RoutedEventArgs e)
        {
            PieChartWindow pieChartWindow = new PieChartWindow();
            pieChartWindow.ShowDialog();
        }

        private void btnRemoveRecipe_Click(object sender, RoutedEventArgs e)
        {
            RemoveRecipeWindow removeRecipeWindow = new RemoveRecipeWindow();
            removeRecipeWindow.ShowDialog();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
